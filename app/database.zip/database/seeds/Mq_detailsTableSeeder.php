<?php

class Mq_detailsTableSeeder extends Seeder {

    public function run()
    {
    	// Uncomment the below to wipe the table clean before populating
    	// DB::table('mq_details')->delete();

        $pq_details = array(

        );

        // Uncomment the below to run the seeder
        // DB::table('mq_details')->insert($pq_details);
    }

}