<?php

class Po_detailsTableSeeder extends Seeder {

    public function run()
    {
    	// Uncomment the below to wipe the table clean before populating
    	 DB::table('po_details')->delete();

        $po_details = array(

        );

        // Uncomment the below to run the seeder
//         DB::table('po_details')->insert($po_details);
    }

}