<?php

class Production_recordsTableSeeder extends Seeder {

    public function run()
    {
    	// Uncomment the below to wipe the table clean before populating
    	// DB::table('production_records')->delete();

        $production_records = array(

        );

        // Uncomment the below to run the seeder
        // DB::table('production_records')->insert($production_records);
    }

}