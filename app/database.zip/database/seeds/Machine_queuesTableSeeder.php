<?php

class Machine_queuesTableSeeder extends Seeder {

    public function run()
    {
    	// Uncomment the below to wipe the table clean before populating
    	// DB::table('machine_queues')->delete();

        $production_queues = array(

        );

        // Uncomment the below to run the seeder
        // DB::table('machine_queues')->insert($production_queues);
    }

}