<?php

class Delivery_queuesTableSeeder extends Seeder {

    public function run()
    {
    	// Uncomment the below to wipe the table clean before populating
    	// DB::table('delivery_queues')->delete();

        $delivery_queues = array(

        );

        // Uncomment the below to run the seeder
        // DB::table('delivery_queues')->insert($delivery_queues);
    }

}