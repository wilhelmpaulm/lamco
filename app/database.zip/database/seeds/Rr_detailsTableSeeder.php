<?php

class Rr_detailsTableSeeder extends Seeder {

    public function run()
    {
    	// Uncomment the below to wipe the table clean before populating
    	 DB::table('rr_details')->delete();

        $rr_details = array(

        );

        // Uncomment the below to run the seeder
//         DB::table('rr_details')->insert($rr_details);
    }

}