<?php

class Dq_detailsTableSeeder extends Seeder {

    public function run()
    {
    	// Uncomment the below to wipe the table clean before populating
    	// DB::table('dq_details')->delete();

        $dq_details = array(

        );

        // Uncomment the below to run the seeder
        // DB::table('dq_details')->insert($dq_details);
    }

}