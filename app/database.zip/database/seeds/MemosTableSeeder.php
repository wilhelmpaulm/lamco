<?php

class MemosTableSeeder extends Seeder {

    public function run()
    {
    	// Uncomment the below to wipe the table clean before populating
    	// DB::table('memos')->delete();

        $memos = array(

        );

        // Uncomment the below to run the seeder
        // DB::table('memos')->insert($memos);
    }

}